
-- Esercizio 1 Effettuate un’esplorazione preliminare del database.
SHOW TABLES;


-- Esercizio 2 Scoprite quanti clienti si sono registrati nel 2006. 
SELECT 
    customer_id, first_name, last_name
FROM
    customer
WHERE
    YEAR(create_Date) = '2006';
    
    
    -- Esercizio 3 Trovate il numero totale di noleggi effettuati il giorno 2006-02-14
SELECT 
    *
FROM
    rental
WHERE
    rental_date LIKE '2006-02-14%'; 
  
  
  -- Esercizio 4 Elencate tutti i film noleggiati nell’ultima settimana e tutte le informazioni legate al cliente che li ha noleggiati. 
SELECT 
    film.title,
    customer.first_name AS nome,
    customer.last_name AS cognome,
    customer.email AS mail,
    customer.customer_id,
    rental.rental_date
FROM
    rental
        JOIN
    inventory ON rental.inventory_id = inventory.inventory_id
        JOIN
    film ON inventory.film_id = film.film_id
        JOIN
    customer ON rental.customer_id = customer.customer_id
WHERE
    DATE(rental.rental_date) BETWEEN DATE('2006-02-08') AND DATE('2006-02-14');


--   Esercizio 5 Calcolate la durata media del noleggio per ogni categoria di film.
SELECT 
    film_category.category_id,
    category.name,
    AVG(film.rental_duration) AS Media_Noleggio
FROM
    film
        JOIN
    film_category ON film.film_id = film_category.film_id
        JOIN
    category ON category.category_id = film_category.category_id
GROUP BY film_category.category_id , category.name;


-- Esercizio 6 Trovate la durata del noleggio più lungo.
SELECT 
    MAX(film.rental_duration) AS Noleggio_Più_Lungo
FROM
    film
  