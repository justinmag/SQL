
-- DATI CLIENTI
INSERT INTO CLIENTE (NOME,EMAIL)
VALUES('ANTONIO',''),
('BATTISTA','battista@mailmail.it'),
('MARIA','maria@posta.it'),
('FRANCA','franca@lettere.it'),
('ETTORE',''),
('ARIANNA','arianna@posta.it'),
('PIERO','piero@lavoro.it');

SELECT 
    *
FROM
    CLIENTE;