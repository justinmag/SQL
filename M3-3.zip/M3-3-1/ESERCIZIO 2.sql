-- ESERCIZIO 2
-- elenco visualizzazione tabelle

SELECT 
    *
FROM
    album;
SELECT 
    *
FROM
    artist;
SELECT 
    *
FROM
    customer;
SELECT 
    *
FROM
    employee;
SELECT 
    *
FROM
    genre;
SELECT 
    *
FROM
    invoice;
SELECT 
    *
FROM
    invoiceline;
SELECT 
    *
FROM
    mediatype;
SELECT 
    *
FROM
    playlist;
SELECT 
    *
FROM
    playlisttrack;
SELECT 
    *
FROM
    track;


-- ES1 Tracce (pop o rock) ordinate 
SELECT 
    track.Name, genre.Name
FROM
    track
        RIGHT JOIN
    genre ON track.GenreId = genre.GenreId
WHERE
    genre.Name = 'Pop'
        OR genre.Name = 'Rock';



-- ES2 Artisti E/O album che iniziano per 'A'
SELECT 
    artist.Name, album.Title
FROM
    artist
        LEFT JOIN
    album ON artist.ArtistId = album.ArtistId
WHERE
    artist.Name LIKE ('A%')
        OR album.Title LIKE ('A%');

-- ES3
-- NULL


-- ES4 Tracce (jazz) o (più lunghe di 3 min)
SELECT 
    track.Name, track.Milliseconds, genre.Name
FROM
    track
        JOIN
    genre ON track.GenreId = genre.GenreId
WHERE
    genre.Name = 'Jazz'
        OR track.Milliseconds > 180000;


-- ES 5 Tracce più lunghe della media
-- MEDIA
SELECT 
    AVG(Milliseconds) AS MEDIA
FROM
    track;
-- RISOLUZIONE
SELECT 
    Name
FROM
    track
WHERE
    Milliseconds > 393599.2121;


-- ES6 Generi con (Tracce più lunge di 4min)
SELECT DISTINCT
    genre.Name
FROM
    genre
        JOIN
    track ON genre.GenreId = track.GenreId
WHERE
    Milliseconds > 240000;


-- ES7  artisti con più di un album
SELECT 
    artist.Name, COUNT(album.Title) AS A
FROM
    artist
        JOIN
    album ON artist.ArtistId = album.ArtistId
GROUP BY artist.Name
HAVING A <> 1;



--  RISOLUZIONE ES 8
SELECT TITLE, NAME, MILLISECONDS

FROM (SELECT TITLE, T.NAME, MILLISECONDS, ROW_NUMBER() OVER( PARTITION BY TITLE ORDER BY  T.MILLISECONDS DESC) AS RN
-- T.*, A.TITLE, ROW_NUMBER() OVER( PARTITION BY T.ALBUMID ORDER BY  T.MILLISECONDS DESC) AS RN
FROM TRACK AS T
JOIN ALBUM AS A ON T.ALBUMID=A.ALBUMID) B
WHERE RN=1;


-- ES 8
SELECT 
    album.Title, AVG(track.Milliseconds)
FROM
    track
        LEFT JOIN
    album ON track.AlbumId = album.AlbumId
GROUP BY 1;



-- ES 9
SELECT 
    Title, COUNT(DISTINCT track.Name) AS num_track
FROM
    track
        LEFT JOIN
    album ON track.AlbumId = album.AlbumId
GROUP BY album.Title
HAVING num_track > 20;








