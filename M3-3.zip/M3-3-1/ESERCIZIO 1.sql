-- elenco tabelle nello schema
show tables;

-- elenco visualizzazione tabelle
SELECT 
    *
FROM
    album;
SELECT 
    *
FROM
    artist;
SELECT 
    *
FROM
    customer;
SELECT 
    *
FROM
    employee;
SELECT 
    *
FROM
    genre;
SELECT 
    *
FROM
    invoice;
SELECT 
    *
FROM
    invoiceline;
SELECT 
    *
FROM
    mediatype;
SELECT 
    *
FROM
    playlist;
SELECT 
    *
FROM
    playlisttrack;
SELECT 
    *
FROM
    track;


-- prime 10 righe tabella album
SELECT 
    *
FROM
    album
LIMIT 10;
 
 
 -- n°totale canzoni in Tracks
SELECT 
    COUNT(Name), COUNT(DISTINCT Name)
FROM
    track;

 
 -- categorie in tabella genre
SELECT DISTINCT
    (Name)
FROM
    genre;

 -- nome tracce con genere associato
SELECT 
    track.Name, track.GenreId, genre.Name
FROM
    track
        LEFT JOIN
    genre ON track.GenreId = genre.GenreId;

 
 -- nome artista con almeno un album associato
SELECT 
    artist.Name, album.Title
FROM
    artist
        RIGHT JOIN
    album ON artist.ArtistId = album.ArtistId;
-- senza album
SELECT 
    artist.Name, album.Title
FROM
    artist
        LEFT JOIN
    album ON artist.ArtistId = album.ArtistId
WHERE
    Title IS NULL;


-- nome traccia, genere, tipo media
SELECT 
    track.Name, genre.Name, mediatype.Name
FROM
    track
        JOIN
    mediatype ON mediatype.MediaTypeId = track.MediaTypeId
        JOIN
    genre ON track.GenreId = genre.GenreId;

-- artisti e corrispettivi album
SELECT 
    artist.Name, album.Title
FROM
    artist
        JOIN
    album ON artist.ArtistId = album.ArtistId
ORDER BY Name ASC;
