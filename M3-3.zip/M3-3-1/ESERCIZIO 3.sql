

-- elenco visualizzazione tabelle
SELECT 
    *
FROM
    album;
SELECT 
    *
FROM
    artist;
SELECT 
    *
FROM
    customer;
SELECT 
    *
FROM
    employee;
SELECT 
    *
FROM
    genre;
SELECT 
    *
FROM
    invoice;
SELECT 
    *
FROM
    invoiceline;
SELECT 
    *
FROM
    mediatype;
SELECT 
    *
FROM
    playlist;
SELECT 
    *
FROM
    playlisttrack;
SELECT 
    *
FROM
    track;

-- ES1
SELECT 
    genre.Name, COUNT(track.Name) AS N°T
FROM
    genre
        LEFT JOIN
    track ON genre.GenreId = track.GenreId
GROUP BY genre.Name
HAVING N°T > 10
ORDER BY N°T DESC;


-- ES2
SELECT 
    Name, UnitPrice
FROM
    track
ORDER BY UnitPrice DESC
LIMIT 3;


-- E3
SELECT 
    Name, Composer, Milliseconds
FROM
    track
WHERE
    Milliseconds > 360000
ORDER BY Milliseconds DESC;


-- ES4
SELECT 
    genre.Name, AVG(Milliseconds)
FROM
    genre
        JOIN
    track ON genre.GenreId = track.GenreId
GROUP BY genre.Name;


-- ES5
SELECT 
    track.Name, genre.Name
FROM
    track
        JOIN
    genre ON genre.GenreId = track.GenreId
WHERE
    track.Name LIKE ('Love%')
        OR track.Name LIKE ('%Love%')
        OR track.Name LIKE ('%Love')
ORDER BY genre.Name ASC , track.Name ASC;



-- ES6
SELECT 
    mediatype.Name, AVG(UnitPrice) AS C_MEDIO
FROM
    mediatype
        JOIN
    track ON mediatype.MediaTypeId = track.MediaTypeId
GROUP BY mediatype.Name
ORDER BY C_MEDIO DESC;



-- ES7
SELECT 
    genre.Name, COUNT(track.Name) AS N°T
FROM
    genre
        LEFT JOIN
    track ON genre.GenreId = track.GenreId
GROUP BY genre.Name
ORDER BY N°T DESC
LIMIT 1;



-- 8
SELECT 
    *
FROM
    artist
WHERE
    Name = 'The Rolling Stones';

-- TRS HANNO 3 ALBUM
SELECT 
    COUNT(album.Title), artist.Name
FROM
    artist
        JOIN
    album ON artist.ArtistId = album.ArtistId
GROUP BY artist.Name
HAVING COUNT(album.Title) = 3
ORDER BY artist.Name = 'The Rolling Stones' DESC;



-- 9
SELECT 
    album.Title,
    SUM(UnitPrice) AS COST_ALBUM,
    COUNT(Title) AS N°TRACCE
FROM
    album
        JOIN
    track ON album.AlbumId = track.AlbumId
GROUP BY album.Title
ORDER BY SUM(UnitPrice) DESC
LIMIT 1;


